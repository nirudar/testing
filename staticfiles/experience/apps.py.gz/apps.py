from django.apps import AppConfig


class ExperienceConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'experience'
